#!/usr/bin/env python3
"""
Task 1 - Voice Assistant (Advanced tier; includes every Beginner feature)

Run:
    python voice_assistant.py          # microphone + speech output
    python voice_assistant.py --text   # type instead of speaking (no microphone needed)
    python voice_assistant.py --mute   # no text-to-speech, print replies only

Beginner features
    * voice input via speech_recognition, spoken replies via pyttsx3
    * "hello" greeting, current time and date, web search in the browser
    * asks the user to repeat when speech is not understood

Advanced features
    * intent recognition on free-form sentences (stemmed, weighted scoring + entity extraction)
    * email by voice (smtplib), timed reminders with audible alert
    * live weather (OpenWeatherMap), general questions (local knowledge base + Wikipedia)
    * custom commands from assistant_config.json or added by voice
"""
from __future__ import annotations

import argparse
import datetime as dt
import difflib
import json
import os
import re
import smtplib
import ssl
import sys
import threading
import webbrowser
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import quote, quote_plus

try:
    import requests
except ImportError:  # handled at call time
    requests = None

try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

try:  # PorterStemmer needs no extra corpus download
    from nltk.stem import PorterStemmer

    _stem = PorterStemmer().stem
except Exception:  # nltk missing -> tiny fallback stemmer

    def _stem(word: str) -> str:
        for suffix in ("ing", "ed", "es", "s"):
            if word.endswith(suffix) and len(word) - len(suffix) >= 3:
                return word[: -len(suffix)]
        return word


CONFIG_PATH = Path(__file__).with_name("assistant_config.json")

DEFAULT_CONFIG = {
    "default_city": "",
    "contacts": {},
    "custom_commands": {
        "open youtube": {"type": "url", "value": "https://www.youtube.com"},
        "who made you": {"type": "speak", "value": "I was built as a Python internship project."},
    },
    "knowledge_base": {
        "who created python": "Python was created by Guido van Rossum and first released in 1991.",
        "what is the capital of india": "The capital of India is New Delhi.",
        "what is the speed of light": "The speed of light is about 299,792 kilometres per second.",
        "how many days are in a year": "A year has 365 days, or 366 in a leap year.",
    },
}

# ----------------------------------------------------------------------------------------
# Intent recognition
# ----------------------------------------------------------------------------------------
_RAW_INTENTS = {
    "time": {"time": 3, "clock": 2, "hour": 1},
    "date": {"date": 3, "day": 2, "today": 1, "calendar": 2, "month": 1, "year": 1},
    "weather": {"weather": 3, "forecast": 3, "temperature": 3, "rain": 2, "sunny": 2,
                "humid": 2, "climate": 2, "hot": 1, "cold": 1},
    "search": {"search": 3, "google": 3, "lookup": 3, "browse": 2, "find": 1, "web": 1, "internet": 1,
               "tutorial": 3, "course": 2, "study": 2, "learn": 1},
    "email": {"email": 3, "mail": 3, "message": 1, "send": 1},
    "reminder": {"remind": 4, "reminder": 4, "timer": 4, "alarm": 4, "notify": 2, "alert": 1},
    "add_command": {"add": 1, "new": 1, "custom": 2, "command": 2, "teach": 2, "learn": 1},
    "help": {"help": 3, "capabilities": 3, "abilities": 3},
    "exit": {"bye": 3, "goodbye": 3, "exit": 3, "quit": 3, "stop": 2, "shutdown": 3},
    "greeting": {"hello": 3, "hi": 3, "hey": 3, "greetings": 3, "good": 1, "morning": 2,
                 "afternoon": 2, "evening": 2},  # last, so it loses ties
}
INTENTS = {i: {_stem(k): w for k, w in kw.items()} for i, kw in _RAW_INTENTS.items()}
QUESTION_START = re.compile(
    r"^(what|who|whom|whose|when|where|why|how|which|is|are|was|were|does|do|did|can|define|"
    r"explain|describe|tell me)\b"
)


def normalize(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9'\s.@-]", " ", text)
    return re.sub(r"\s+", " ", text).strip(" .")


def classify(norm: str) -> tuple[str, int]:
    """Return (intent, score). Falls back to 'qa' for question-like input, else 'unknown'."""
    tokens = [_stem(t) for t in re.findall(r"[a-z0-9']+", norm)]
    best, best_score = "unknown", 0
    for intent, keywords in INTENTS.items():
        score = sum(keywords.get(t, 0) for t in tokens)
        if score > best_score:
            best, best_score = intent, score
    if best_score >= 2:
        return best, best_score
    if QUESTION_START.match(norm):
        return "qa", 0
    return "unknown", 0


_NUM_WORDS = {
    "a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
    "eight": 8, "nine": 9, "ten": 10, "fifteen": 15, "twenty": 20, "thirty": 30,
    "forty five": 45, "forty": 40, "fifty": 50, "sixty": 60,
}
_NUM_PATTERN = "|".join(sorted(map(re.escape, _NUM_WORDS), key=len, reverse=True))
_DURATION_RE = re.compile(
    rf"(\d+(?:\.\d+)?|{_NUM_PATTERN})\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\b"
)


def parse_duration(text: str):
    """Return (seconds, match) for phrases like '5 minutes', 'two hours', 'half an hour'."""
    if "half an hour" in text:
        return 1800, re.search(r"half an hour", text)
    m = _DURATION_RE.search(text)
    if not m:
        return None, None
    qty = m.group(1)
    value = float(qty) if qty[0].isdigit() else float(_NUM_WORDS[qty])
    unit = m.group(2)
    factor = 1 if unit.startswith("sec") else 60 if unit.startswith("min") else 3600
    return int(value * factor), m


def format_duration(seconds: int) -> str:
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    parts = []
    for n, name in ((h, "hour"), (m, "minute"), (s, "second")):
        if n:
            parts.append(f"{n} {name}{'s' if n != 1 else ''}")
    return " ".join(parts) or "0 seconds"


def is_yes(text) -> bool:
    return bool(text and re.search(r"\b(yes|yeah|yep|sure|ok|okay|send|confirm|go ahead)\b", text.lower()))


# ----------------------------------------------------------------------------------------
# Config helpers
# ----------------------------------------------------------------------------------------
def load_config(path: Path) -> dict:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    try:
        with open(path, encoding="utf-8") as fh:
            user = json.load(fh)
        for key, value in user.items():
            if isinstance(value, dict) and isinstance(cfg.get(key), dict):
                cfg[key].update(value)
            else:
                cfg[key] = value
    except FileNotFoundError:
        pass
    except (json.JSONDecodeError, OSError) as exc:
        print(f"[warning] Could not read {path.name}: {exc}. Using defaults.")
    return cfg


def save_config(path: Path, cfg: dict) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, indent=2)


# ----------------------------------------------------------------------------------------
# Assistant
# ----------------------------------------------------------------------------------------
class VoiceAssistant:
    def __init__(self, text_mode: bool = False, mute: bool = False, config_path: Path = CONFIG_PATH):
        self.config_path = Path(config_path)
        self.config = load_config(self.config_path)
        self.text_mode = text_mode or sr is None
        self.running = True
        self.reminders: list[threading.Timer] = []
        self._speech_lock = threading.Lock()
        self.engine = None
        self.recognizer = sr.Recognizer() if sr else None

        if sr is None and not text_mode:
            print("[info] speech_recognition is not installed - using typed input.")
        if pyttsx3 is not None and not mute:
            try:
                self.engine = pyttsx3.init()
            except Exception as exc:  # no speech driver available
                print(f"[info] Text-to-speech unavailable ({exc}); replies will be printed only.")

    # ---- input / output ----------------------------------------------------------------
    def speak(self, text: str) -> None:
        print(f"Assistant: {text}")
        if self.engine is not None:
            with self._speech_lock:
                try:
                    self.engine.say(text)
                    self.engine.runAndWait()
                except RuntimeError:
                    pass

    def listen(self):
        """Return recognised text, or None if nothing usable was heard."""
        if self.text_mode:
            try:
                return input("You: ").strip() or None
            except EOFError:
                self.running = False
                return None
        try:
            with sr.Microphone() as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                print("Listening...")
                audio = self.recognizer.listen(source, timeout=8, phrase_time_limit=10)
            text = self.recognizer.recognize_google(audio)
            print(f"You: {text}")
            return text.strip()
        except (sr.WaitTimeoutError, sr.UnknownValueError):
            return None
        except sr.RequestError:
            self.speak("I can't reach the speech recognition service. Please check your internet connection.")
            return None
        except (OSError, AttributeError):
            self.speak("I can't access a microphone, so I'll switch to typed input.")
            self.text_mode = True
            return None

    def ask(self, question: str):
        """Speak a question and return the answer (asks once more if it was not understood)."""
        self.speak(question)
        for _ in range(2):
            answer = self.listen()
            if answer:
                return answer
            if not self.running:
                return None
            self.speak("Sorry, I didn't catch that. Could you repeat?")
        return None

    # ---- main loop ---------------------------------------------------------------------
    def run(self) -> None:
        self.speak("Voice assistant ready. Say hello, or say help to hear what I can do.")
        while self.running:
            text = self.listen()
            if text is None:
                if self.running:
                    self.speak("Sorry, I didn't catch that. Could you please repeat?")
                continue
            reply = self.handle(text)
            if reply:
                self.speak(reply)

    def handle(self, text: str) -> str:
        norm = normalize(text)
        custom = self.match_custom(norm)
        if custom:
            return self.run_custom(custom)
        intent, _ = classify(norm)
        handler = getattr(self, f"do_{intent}", None)
        if handler is None:
            return self.fallback_search(text)
        return handler(norm)

    def fallback_search(self, text: str) -> str:
        """Unknown request: offer a web search instead of a dead end."""
        answer = self.ask("I'm not sure how to do that directly. Should I search the web for it? Say yes or no.")
        if is_yes(answer):
            query = re.sub(r"^(?:i (?:have|want|need) to|i'd like to|i would like to|please)\s+", "", normalize(text))
            return self.open_search(query or normalize(text))
        return "Okay. Say help to hear what I can do."

    def open_search(self, query: str) -> str:
        webbrowser.open(f"https://www.google.com/search?q={quote_plus(query)}")
        return f"Searching the web for {query}."

    # ---- custom commands ---------------------------------------------------------------
    def match_custom(self, norm: str):
        commands = self.config.get("custom_commands", {})
        for phrase in sorted(commands, key=len, reverse=True):
            if normalize(phrase) and normalize(phrase) in norm:
                return commands[phrase]
        return None

    def run_custom(self, cmd: dict) -> str:
        if cmd.get("type") == "url":
            webbrowser.open(cmd["value"])
            return f"Opening {cmd['value']}"
        return cmd.get("value", "Done.")

    def do_add_command(self, norm: str) -> str:
        phrase = self.ask("What phrase should trigger the new command?")
        if not phrase:
            return "Okay, cancelled."
        kind = self.ask("Should it open a website, or say something back? Say website or say.")
        if not kind:
            return "Okay, cancelled."
        if "web" in kind.lower():
            site = self.ask("Which website address?")
            if not site:
                return "Okay, cancelled."
            site = site.lower().replace(" dot ", ".").replace(" ", "")
            if not site.startswith("http"):
                site = "https://" + site
            cmd = {"type": "url", "value": site}
        else:
            reply = self.ask("What should I say?")
            if not reply:
                return "Okay, cancelled."
            cmd = {"type": "speak", "value": reply}
        self.config.setdefault("custom_commands", {})[normalize(phrase)] = cmd
        try:
            save_config(self.config_path, self.config)
        except OSError as exc:
            return f"I added the command for this session but couldn't save it: {exc}"
        return f"Done. When you say {phrase}, I'll respond."

    # ---- basic intents -----------------------------------------------------------------
    def do_greeting(self, norm: str) -> str:
        return "Hello! I'm your voice assistant. How can I help you today?"

    def do_time(self, norm: str) -> str:
        now = dt.datetime.now()
        if re.search(r"\b(date|day)\b", norm):
            return f"It is {now:%I:%M %p} on {now:%A, %B %d, %Y}.".replace("It is 0", "It is ")
        return f"The time is {now:%I:%M %p}.".lstrip().replace("is 0", "is ")

    def do_date(self, norm: str) -> str:
        now = dt.datetime.now()
        if re.search(r"\btime\b", norm):
            return self.do_time(norm + " date")
        return f"Today is {now:%A, %B %d, %Y}."

    def do_search(self, norm: str) -> str:
        m = re.search(
            r"(?:search(?: the web| google| online)?(?: for)?|google|look ?up|find(?: me)?|browse(?: for)?)\s+(.+)",
            norm,
        )
        if m:
            query = m.group(1)
        elif norm in ("search", "google", "browse", "look up", "lookup", "find"):
            query = ""
        else:  # e.g. "i want to learn python tutorials": use the whole phrase
            query = re.sub(r"^(?:i (?:have|want|need) to|i'd like to|i would like to|please)\s+", "", norm)
        query = re.sub(r"\s+(?:on|in|using) (?:google|the web|the internet|chrome|browser)$", "", query)
        query = re.sub(r"^(?:for|about)\s+", "", query).strip()
        if query in ("", "something", "the web", "the internet", "online"):
            query = self.ask("What would you like me to search for?")
            if not query:
                return "Okay, cancelled the search."
        return self.open_search(query)

    def do_help(self, norm: str) -> str:
        return (
            "I can say hello, tell the time and date, search the web, report the weather, "
            "send an email, set reminders, answer general questions, and learn new commands. "
            "Say goodbye to exit."
        )

    def do_exit(self, norm: str) -> str:
        self.running = False
        pending = [t for t in self.reminders if t.is_alive()]
        if pending:
            for t in pending:
                t.cancel()
            return f"Goodbye! Note: {len(pending)} pending reminder(s) were cancelled as I'm closing."
        return "Goodbye!"

    # ---- reminders ---------------------------------------------------------------------
    def do_reminder(self, norm: str) -> str:
        seconds, match = parse_duration(norm)
        if seconds is None:
            answer = self.ask("How long from now? For example, 5 minutes.")
            seconds, _ = parse_duration(normalize(answer or ""))
            if seconds is None:
                return "Sorry, I couldn't work out the time, so I didn't set a reminder."
        message = "your reminder"
        before = re.search(r"remind me (?:to|about|that)\s+(.+?)\s+(?:in|after)\s", norm + " ")
        after = re.search(r"(?:to|that|about)\s+(.+)$", norm[match.end():]) if match else None
        if before:
            message = before.group(1)
        elif after:
            message = after.group(1)
        timer = threading.Timer(seconds, self._fire_reminder, args=(message,))
        timer.daemon = True
        timer.start()
        self.reminders.append(timer)
        return f"Okay, I'll remind you in {format_duration(seconds)}: {message}."

    def _fire_reminder(self, message: str) -> None:
        self._beep()
        self.speak(f"Reminder: {message}")

    @staticmethod
    def _beep() -> None:
        try:
            import winsound  # Windows only

            for _ in range(3):
                winsound.Beep(1000, 400)
        except ImportError:
            print("\a\a\a", end="", flush=True)

    # ---- weather -----------------------------------------------------------------------
    def do_weather(self, norm: str) -> str:
        m = re.search(
            r"\b(?:in|for|at|of)\s+([a-z][a-z .'-]*?)(?:\s+(?:today|tomorrow|right now|now|please|tonight))?$", norm
        )
        city = m.group(1).strip() if m else ""
        if city in {"today", "tomorrow", "now", "tonight", "me", "the morning", "the evening"}:
            city = ""
        city = city or self.config.get("default_city", "")
        if not city:
            city = self.ask("Which city?")
            if not city:
                return "Okay, cancelled the weather request."
        return self.fetch_weather(normalize(city))

    def fetch_weather(self, city: str) -> str:
        key = os.getenv("OPENWEATHER_API_KEY")
        if not key:
            return "Weather needs an OpenWeatherMap API key. Set the OPENWEATHER_API_KEY environment variable."
        if requests is None:
            return "The requests library is not installed. Run pip install requests."
        try:
            resp = requests.get(
                "https://api.openweathermap.org/data/2.5/weather",
                params={"q": city, "appid": key, "units": "metric"},
                timeout=8,
            )
        except requests.Timeout:
            return "The weather service took too long to respond."
        except requests.RequestException:
            return "I couldn't reach the weather service. Please check your internet connection."
        if resp.status_code == 401:
            return "The weather API key was rejected. Please check OPENWEATHER_API_KEY."
        if resp.status_code == 404:
            return f"I couldn't find a city called {city}."
        if resp.status_code != 200:
            return f"The weather service returned an error ({resp.status_code})."
        data = resp.json()
        desc = data["weather"][0]["description"]
        return (
            f"In {data.get('name', city)} it is {data['main']['temp']:.0f} degrees Celsius with {desc}. "
            f"Humidity is {data['main']['humidity']} percent and wind speed is {data['wind']['speed']} metres per second."
        )

    # ---- email -------------------------------------------------------------------------
    def do_email(self, norm: str) -> str:
        m = re.search(r"\bto\s+([a-z][a-z ]*?)(?:\s+(?:saying|about|with|that)\b.*)?$", norm)
        name = m.group(1).strip() if m else None
        if not name:
            name = self.ask("Who should I send it to?")
            if not name:
                return "Okay, cancelled the email."
            name = normalize(name)
        contacts = {normalize(k): v for k, v in self.config.get("contacts", {}).items()}
        address = contacts.get(name)
        if not address:
            return f"I don't have {name} in your contacts. Add their address under contacts in assistant_config.json."
        subject = self.ask("What is the subject?")
        body = self.ask("What should the message say?") if subject else None
        if not subject or not body:
            return "Okay, cancelled the email."
        if not is_yes(self.ask(f"Send an email to {name} with subject {subject}? Say yes or no.")):
            return "Okay, I won't send it."
        return self.send_email(address, subject, body)

    def send_email(self, to_addr: str, subject: str, body: str) -> str:
        sender = os.getenv("EMAIL_ADDRESS")
        password = os.getenv("EMAIL_PASSWORD")
        if not sender or not password:
            return ("Email credentials are not set, so I did not send anything (dry run). "
                    "Set EMAIL_ADDRESS and EMAIL_PASSWORD using a test account.")
        msg = EmailMessage()
        msg["From"], msg["To"], msg["Subject"] = sender, to_addr, subject
        msg.set_content(body)
        try:
            with smtplib.SMTP(os.getenv("SMTP_SERVER", "smtp.gmail.com"), int(os.getenv("SMTP_PORT", "587")), timeout=15) as smtp:
                smtp.starttls(context=ssl.create_default_context())
                smtp.login(sender, password)
                smtp.send_message(msg)
        except smtplib.SMTPAuthenticationError:
            return "Email login failed. Check the account and use an app password."
        except (smtplib.SMTPException, OSError) as exc:
            return f"I couldn't send the email: {exc}"
        return "Your email has been sent."

    # ---- general knowledge -------------------------------------------------------------
    def do_qa(self, norm: str) -> str:
        answer = self.local_answer(norm)
        if answer:
            return answer
        topic = re.sub(
            r"^(?:please )?(?:tell me about|tell me|what is|what are|what's|who is|who was|who are|define|"
            r"explain|describe|meaning of|what does)\s+",
            "", norm,
        )
        topic = re.sub(r"^(?:a|an|the)\s+", "", topic)
        topic = re.sub(r"\s+mean$", "", topic).strip()
        if not topic:
            return "What would you like to know about?"
        return self.wikipedia_answer(topic)

    def local_answer(self, norm: str):
        stop = {"the", "a", "an", "is", "are", "of", "me", "please", "tell", "about"}
        words = {_stem(w) for w in norm.split() if w not in stop}
        best, best_score = None, 0.0
        for question, answer in self.config.get("knowledge_base", {}).items():
            qn = normalize(question)
            qwords = {_stem(w) for w in qn.split() if w not in stop}
            overlap = len(words & qwords) / len(qwords) if qwords else 0
            score = max(overlap if overlap >= 0.75 else 0, difflib.SequenceMatcher(None, norm, qn).ratio())
            if score > best_score:
                best, best_score = answer, score
        return best if best_score >= 0.75 else None

    def wikipedia_answer(self, topic: str) -> str:
        if requests is None:
            return "The requests library is not installed, so I can't look that up."
        headers = {"User-Agent": "StudentVoiceAssistant/1.0 (internship project)"}
        try:
            found = requests.get(
                "https://en.wikipedia.org/w/api.php",
                params={"action": "query", "list": "search", "srsearch": topic, "format": "json", "srlimit": 1},
                headers=headers, timeout=8,
            ).json()["query"]["search"]
            if not found:
                return f"I couldn't find anything about {topic}."
            summary = requests.get(
                "https://en.wikipedia.org/api/rest_v1/page/summary/" + quote(found[0]["title"].replace(" ", "_")),
                headers=headers, timeout=8,
            ).json()
            extract = summary.get("extract", "")
        except (requests.RequestException, KeyError, ValueError):
            return "I couldn't reach the knowledge service right now."
        sentences = re.split(r"(?<=[.!?])\s+", extract)
        return " ".join(sentences[:2])[:400] or f"I couldn't find anything about {topic}."


def main() -> None:
    parser = argparse.ArgumentParser(description="Python voice assistant")
    parser.add_argument("--text", action="store_true", help="type commands instead of using the microphone")
    parser.add_argument("--mute", action="store_true", help="do not speak replies aloud")
    parser.add_argument("--config", default=str(CONFIG_PATH), help="path to config JSON")
    args = parser.parse_args()
    try:
        VoiceAssistant(text_mode=args.text, mute=args.mute, config_path=Path(args.config)).run()
    except KeyboardInterrupt:
        print("\nGoodbye!")
        sys.exit(0)


if __name__ == "__main__":
    main()
