# Task 1 - Voice Assistant (Advanced tier)

A Python voice assistant that listens through the microphone, understands free-form sentences, and answers aloud.

## Setup

```bash
pip install -r requirements.txt
```

PyAudio needs a system library for the microphone:

| OS | Command |
|----|---------|
| Windows | `pip install pyaudio` (usually works directly) |
| macOS | `brew install portaudio` then `pip install pyaudio` |
| Linux | `sudo apt install portaudio19-dev python3-pyaudio espeak` |

Optional environment variables (use a **test/dummy** email account):

```bash
export OPENWEATHER_API_KEY="your_key"      # free key from openweathermap.org
export EMAIL_ADDRESS="test.account@gmail.com"
export EMAIL_PASSWORD="app_password"       # Gmail app password, not your real password
# optional: SMTP_SERVER (default smtp.gmail.com), SMTP_PORT (default 587)
```

On Windows PowerShell use `$env:OPENWEATHER_API_KEY="your_key"`.

## Run

```bash
python voice_assistant.py          # speak to it
python voice_assistant.py --text   # type commands (no microphone needed)
python voice_assistant.py --mute   # print replies without speaking
```

## Things to say

| Say | What happens |
|-----|--------------|
| "Hello" | Predefined greeting |
| "What time is it?" / "What's today's date?" | Current time / date |
| "Search for python tutorials" | Opens Google results in the browser |
| "What's the weather in Chennai?" | Live weather from OpenWeatherMap |
| "Remind me to drink water in 10 minutes" | Timer; audible beep plus spoken alert |
| "Send an email to test account" | Asks subject and message, confirms, then sends |
| "Who is Alan Turing?" / "What is photosynthesis?" | Local knowledge base, then Wikipedia |
| "Add a new command" | Asks for a phrase and response, saves to config |
| "Goodbye" | Exits |

If speech isn't understood, the assistant asks you to repeat.

## Feature checklist

**Beginner:** voice input, hello greeting, time and date, web search, repeat-on-error, pyttsx3 replies.
**Advanced:** intent parsing (stemmed keyword weighting plus regex entity extraction, so "could you tell me what the weather is like in Mumbai" works), email via `smtplib`, reminders with audible alert, weather API, QA (local knowledge base plus Wikipedia), custom commands (config file or voice prompt), privacy documentation (below).

## How the intent parsing works

1. Text is normalised and stemmed (NLTK `PorterStemmer`, with a tiny fallback if NLTK is missing).
2. Each intent has weighted keywords; the highest score above a threshold wins.
3. Question-like sentences that match no intent go to general QA.
4. Entities (city, search query, duration, recipient) are pulled out with regular expressions.

## Custom commands

Edit `assistant_config.json`:

```json
"custom_commands": {
  "open github": { "type": "url", "value": "https://github.com" },
  "who made you": { "type": "speak", "value": "A student built me." }
}
```

`contacts` maps spoken names to email addresses; `knowledge_base` maps questions to answers.

## Privacy: what data is processed and how

- **Audio:** captured from the microphone only while the assistant says "Listening...". It is sent to Google's free Web Speech API (`recognize_google`) for transcription. Audio is not saved to disk by this program.
- **Transcribed text:** processed locally for intent detection. It is not logged or stored, except custom commands you explicitly add (saved to `assistant_config.json`).
- **Weather:** the city name is sent to OpenWeatherMap together with your API key.
- **General questions:** the topic is sent to Wikipedia's public API when the local knowledge base has no answer.
- **Email:** recipient, subject and body go to your SMTP server. Credentials are read from environment variables and never written to files. Use a throwaway account.
- **Reminders** live in memory only and are lost when the program exits.
- To avoid sending audio to any service, use `--text` mode.
