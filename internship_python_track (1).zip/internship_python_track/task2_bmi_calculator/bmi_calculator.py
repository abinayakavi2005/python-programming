#!/usr/bin/env python3
"""
Task 2 - BMI Calculator (Advanced tier; includes every Beginner feature)

Run:
    python bmi_calculator.py          # GUI (tkinter + SQLite + matplotlib trend chart)
    python bmi_calculator.py --cli    # Beginner command-line version
    python bmi_calculator.py --db my.db   # use a different database file
"""
from __future__ import annotations

import argparse
import math
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import messagebox, ttk
except ImportError:  # tkinter missing -> CLI still works
    tk = None

DEFAULT_DB = Path(__file__).with_name("bmi_records.db")

CATEGORY_COLORS = {
    "Underweight": "#2563eb",  # blue
    "Normal": "#16a34a",       # green
    "Overweight": "#f59e0b",   # orange
    "Obese": "#dc2626",        # red
}


# ----------------------------------------------------------------------------------------
# Core logic (shared by CLI and GUI)
# ----------------------------------------------------------------------------------------
def parse_measurement(text: str, label: str, low: float, high: float, unit: str) -> float:
    """Convert text to a float, rejecting non-numeric, non-finite, negative and implausible values."""
    text = (text or "").strip()
    if not text:
        raise ValueError(f"Please enter your {label}.")
    try:
        value = float(text)
    except ValueError:
        raise ValueError(f"{label.capitalize()} must be a number (for example {low + (high - low) / 3:.1f}), not '{text}'.")
    if not math.isfinite(value):
        raise ValueError(f"{label.capitalize()} must be a real number.")
    if value <= 0:
        raise ValueError(f"{label.capitalize()} must be greater than zero (negative values are not allowed).")
    if not low <= value <= high:
        hint = " Height must be in metres, e.g. 1.75, not centimetres." if label == "height" and value > high else ""
        raise ValueError(f"{label.capitalize()} should be between {low} and {high} {unit}.{hint}")
    return value


def parse_weight(text: str) -> float:
    return parse_measurement(text, "weight", 2, 500, "kg")


def parse_height(text: str) -> float:
    return parse_measurement(text, "height", 0.5, 2.8, "m")


def calculate_bmi(weight_kg: float, height_m: float) -> float:
    """BMI = weight / height^2, rounded to 2 decimal places."""
    if weight_kg <= 0 or height_m <= 0:
        raise ValueError("Weight and height must be positive.")
    return round(weight_kg / (height_m ** 2), 2)


def classify_bmi(bmi: float) -> str:
    """Underweight < 18.5, Normal 18.5-24.9, Overweight 25-29.9, Obese >= 30 (on the rounded value shown)."""
    if bmi < 18.5:
        return "Underweight"
    if bmi < 25:
        return "Normal"
    if bmi < 30:
        return "Overweight"
    return "Obese"


# ----------------------------------------------------------------------------------------
# Persistence (SQLite)
# ----------------------------------------------------------------------------------------
class DatabaseError(Exception):
    """Raised for any database read/write failure, with a user-friendly message."""


class BMIDatabase:
    def __init__(self, path: Path | str = DEFAULT_DB):
        self.path = str(path)
        self._execute(
            """CREATE TABLE IF NOT EXISTS records (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   user TEXT NOT NULL,
                   weight_kg REAL NOT NULL,
                   height_m REAL NOT NULL,
                   bmi REAL NOT NULL,
                   category TEXT NOT NULL,
                   recorded_at TEXT NOT NULL)"""
        )

    def _execute(self, sql: str, params: tuple = (), fetch: bool = False):
        try:
            with sqlite3.connect(self.path) as conn:
                cur = conn.execute(sql, params)
                return cur.fetchall() if fetch else None
        except sqlite3.Error as exc:
            raise DatabaseError(f"Database error: {exc}") from exc

    def add_record(self, user: str, weight_kg: float, height_m: float, bmi: float, category: str) -> None:
        self._execute(
            "INSERT INTO records (user, weight_kg, height_m, bmi, category, recorded_at) VALUES (?,?,?,?,?,?)",
            (user, weight_kg, height_m, bmi, category, datetime.now().isoformat(timespec="seconds")),
        )

    def users(self) -> list[str]:
        rows = self._execute("SELECT DISTINCT user FROM records ORDER BY user COLLATE NOCASE", fetch=True)
        return [r[0] for r in rows]

    def history(self, user: str) -> list[tuple]:
        """Rows of (recorded_at, weight_kg, height_m, bmi, category), oldest first."""
        return self._execute(
            "SELECT recorded_at, weight_kg, height_m, bmi, category FROM records "
            "WHERE user = ? COLLATE NOCASE ORDER BY recorded_at, id",
            (user,), fetch=True,
        )


# ----------------------------------------------------------------------------------------
# Beginner: command-line version
# ----------------------------------------------------------------------------------------
def _prompt(label: str, parser) -> float:
    while True:
        try:
            return parser(input(f"Enter your {label}: "))
        except ValueError as exc:
            print(f"  Error: {exc}")


def run_cli() -> None:
    print("=== BMI Calculator ===")
    while True:
        weight = _prompt("weight in kg", parse_weight)
        height = _prompt("height in metres (e.g. 1.75)", parse_height)
        bmi = calculate_bmi(weight, height)
        print(f"\nYour BMI is {bmi:.2f} - {classify_bmi(bmi)}\n")
        if input("Calculate another? (y/n): ").strip().lower() != "y":
            break


# ----------------------------------------------------------------------------------------
# Advanced: GUI
# ----------------------------------------------------------------------------------------
class BMIApp:
    def __init__(self, root, db: BMIDatabase):
        self.root, self.db = root, db
        self.current = None  # (weight, height, bmi, category) from the last successful calculation
        root.title("BMI Calculator")
        root.minsize(620, 560)

        frm = ttk.Frame(root, padding=14)
        frm.pack(fill="both", expand=True)
        frm.columnconfigure(1, weight=1)

        ttk.Label(frm, text="BMI Calculator", font=("Segoe UI", 16, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")

        ttk.Label(frm, text="User name:").grid(row=1, column=0, sticky="w", pady=4)
        self.user_box = ttk.Combobox(frm, values=self._safe_users())
        self.user_box.grid(row=1, column=1, columnspan=2, sticky="ew", pady=4)
        self.user_box.bind("<<ComboboxSelected>>", lambda _e: self.refresh_history())
        self.user_box.bind("<FocusOut>", lambda _e: self.refresh_history())

        ttk.Label(frm, text="Weight (kg):").grid(row=2, column=0, sticky="w", pady=4)
        self.weight_entry = ttk.Entry(frm)
        self.weight_entry.grid(row=2, column=1, columnspan=2, sticky="ew", pady=4)

        ttk.Label(frm, text="Height (m):").grid(row=3, column=0, sticky="w", pady=4)
        self.height_entry = ttk.Entry(frm)
        self.height_entry.grid(row=3, column=1, columnspan=2, sticky="ew", pady=4)

        buttons = ttk.Frame(frm)
        buttons.grid(row=4, column=0, columnspan=3, pady=8, sticky="w")
        ttk.Button(buttons, text="Calculate", command=self.calculate).pack(side="left", padx=(0, 6))
        self.save_btn = ttk.Button(buttons, text="Save record", command=self.save, state="disabled")
        self.save_btn.pack(side="left", padx=6)
        ttk.Button(buttons, text="Show trend", command=self.show_trend).pack(side="left", padx=6)

        self.result = tk.Label(frm, text="Enter weight and height, then press Calculate",
                               font=("Segoe UI", 13, "bold"), bg="#e5e7eb", fg="#111827", pady=14)
        self.result.grid(row=5, column=0, columnspan=3, sticky="ew")

        self.message = ttk.Label(frm, text="", foreground="#b91c1c", wraplength=560)
        self.message.grid(row=6, column=0, columnspan=3, sticky="w", pady=(6, 2))

        ttk.Label(frm, text="History for selected user", font=("Segoe UI", 10, "bold")).grid(
            row=7, column=0, columnspan=3, sticky="w", pady=(8, 2))
        cols = ("date", "weight", "height", "bmi", "category")
        self.table = ttk.Treeview(frm, columns=cols, show="headings", height=8)
        for col, text, width in (("date", "Date", 150), ("weight", "Weight (kg)", 90),
                                 ("height", "Height (m)", 90), ("bmi", "BMI", 70), ("category", "Category", 100)):
            self.table.heading(col, text=text)
            self.table.column(col, width=width, anchor="center")
        self.table.grid(row=8, column=0, columnspan=3, sticky="nsew")
        frm.rowconfigure(8, weight=1)
        for cat, color in CATEGORY_COLORS.items():
            self.table.tag_configure(cat, foreground=color)

        root.bind("<Return>", lambda _e: self.calculate())

    # ---- helpers -----------------------------------------------------------------------
    def _safe_users(self) -> list[str]:
        try:
            return self.db.users()
        except DatabaseError as exc:
            messagebox.showerror("Database", str(exc))
            return []

    def _error(self, text: str) -> None:
        self.message.config(text=text)

    # ---- actions -----------------------------------------------------------------------
    def calculate(self) -> bool:
        self._error("")
        try:
            weight = parse_weight(self.weight_entry.get())
            height = parse_height(self.height_entry.get())
        except ValueError as exc:
            self.current = None
            self.save_btn.config(state="disabled")
            self.result.config(text="No result", bg="#e5e7eb", fg="#111827")
            self._error(str(exc))
            return False
        bmi = calculate_bmi(weight, height)
        category = classify_bmi(bmi)
        self.current = (weight, height, bmi, category)
        self.result.config(text=f"BMI {bmi:.2f} - {category}", bg=CATEGORY_COLORS[category], fg="white")
        self.save_btn.config(state="normal")
        return True

    def save(self) -> None:
        user = self.user_box.get().strip()
        if not user:
            self._error("Enter a user name so the record can be saved.")
            return
        if not self.calculate():
            return
        weight, height, bmi, category = self.current
        try:
            self.db.add_record(user, weight, height, bmi, category)
        except DatabaseError as exc:
            messagebox.showerror("Could not save", str(exc))
            return
        self.user_box.config(values=self._safe_users())
        self.refresh_history()
        self._error("")
        self.message.config(text=f"Saved record for {user}.", foreground="#166534")
        self.root.after(2500, lambda: self.message.config(text="", foreground="#b91c1c"))

    def refresh_history(self) -> None:
        self.table.delete(*self.table.get_children())
        user = self.user_box.get().strip()
        if not user:
            return
        try:
            rows = self.db.history(user)
        except DatabaseError as exc:
            self._error(str(exc))
            return
        for when, w, h, bmi, cat in rows:
            self.table.insert("", "end", values=(when.replace("T", " "), w, h, f"{bmi:.2f}", cat), tags=(cat,))

    def show_trend(self) -> None:
        user = self.user_box.get().strip()
        if not user:
            self._error("Select or type a user name to see their trend.")
            return
        try:
            rows = self.db.history(user)
        except DatabaseError as exc:
            messagebox.showerror("Database", str(exc))
            return
        if not rows:
            messagebox.showinfo("No data", f"No saved records for '{user}' yet.")
            return
        try:
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            from matplotlib.figure import Figure
        except ImportError:
            messagebox.showerror("Missing library", "matplotlib is required for the trend chart.\nRun: pip install matplotlib")
            return

        dates = [datetime.fromisoformat(r[0]) for r in rows]
        values = [r[3] for r in rows]
        win = tk.Toplevel(self.root)
        win.title(f"BMI trend - {user}")
        fig = Figure(figsize=(6.5, 4), dpi=100)
        ax = fig.add_subplot(111)
        top = max(35, max(values) + 2)
        bottom = min(15, min(values) - 2)
        for lo, hi, cat in ((bottom, 18.5, "Underweight"), (18.5, 25, "Normal"), (25, 30, "Overweight"), (30, top, "Obese")):
            ax.axhspan(lo, hi, color=CATEGORY_COLORS[cat], alpha=0.12, label=cat)
        ax.plot(dates, values, marker="o", color="#111827", linewidth=2)
        for d, v in zip(dates, values):
            ax.annotate(f"{v:.1f}", (d, v), textcoords="offset points", xytext=(0, 8), ha="center", fontsize=8)
        ax.set_ylim(bottom, top)
        ax.set_ylabel("BMI")
        ax.set_title(f"BMI over time - {user}")
        ax.legend(loc="upper left", fontsize=8, ncol=2)
        fig.autofmt_xdate()
        fig.tight_layout()
        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)


def run_gui(db_path: Path) -> None:
    if tk is None:
        print("tkinter is not available on this system; falling back to the command-line version.")
        return run_cli()
    try:
        db = BMIDatabase(db_path)
    except DatabaseError as exc:
        print(exc)
        sys.exit(1)
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        print(f"Could not open a window ({exc}); falling back to the command-line version.")
        return run_cli()
    BMIApp(root, db)
    root.mainloop()


def main() -> None:
    parser = argparse.ArgumentParser(description="BMI calculator")
    parser.add_argument("--cli", action="store_true", help="run the command-line (Beginner) version")
    parser.add_argument("--db", default=str(DEFAULT_DB), help="SQLite database file for saved records")
    args = parser.parse_args()
    run_cli() if args.cli else run_gui(Path(args.db))


if __name__ == "__main__":
    main()
