# Task 2 - BMI Calculator (Advanced tier)

Calculates Body Mass Index, classifies it, colour-codes the result, saves records per user in SQLite, and plots each user's BMI trend.

## Setup and run

```bash
pip install -r requirements.txt   # only matplotlib; tkinter and sqlite3 ship with Python
python bmi_calculator.py          # GUI
python bmi_calculator.py --cli    # Beginner command-line version
```

On Linux, if tkinter is missing: `sudo apt install python3-tk`.

## How to use the GUI

1. Type a **user name** (or pick an existing one), then enter **weight (kg)** and **height (m)**.
2. Press **Calculate** (or Enter). The result panel is colour-coded:
   blue = Underweight, green = Normal, orange = Overweight, red = Obese.
3. Press **Save record** to store it under that user. The history table updates.
4. Press **Show trend** for a matplotlib line chart of that user's BMI over time, with the category bands shaded.

## Formula and categories

`BMI = weight(kg) / height(m)^2`, shown to 2 decimal places.

| BMI | Category |
|-----|----------|
| < 18.5 | Underweight |
| 18.5 - 24.9 | Normal |
| 25 - 29.9 | Overweight |
| >= 30 | Obese |

## Feature checklist

**Beginner (`--cli`):** prompts for weight and height, formula, categories, 2-decimal output, validation (non-numeric, zero, negative, impossible values, and a hint if height looks like centimetres).
**Advanced (GUI):** tkinter window, labelled inputs and Calculate button, colour-coded result, multi-user records, SQLite persistence, matplotlib trend chart, database error handling (every database call is wrapped; failures show a message box instead of crashing).

## Data storage

Records are saved in `bmi_records.db` next to the script (table `records`: user, weight, height, BMI, category, timestamp). Nothing is sent over the network. Use `--db path.db` for a separate file.

BMI is a screening number only and is not a medical diagnosis.
