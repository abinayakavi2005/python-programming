# Task 3 - Random Password Generator (Advanced tier)

Generates strong random passwords with a GUI, a strength meter, ambiguous-character filtering, and automatic clipboard copy.

## Setup and run

```bash
pip install -r requirements.txt   # pyperclip (tkinter ships with Python)
python password_generator.py         # GUI
python password_generator.py --cli   # Beginner command-line version
```

On Linux, `pyperclip` needs `xclip` or `xsel` (`sudo apt install xclip`); if missing, the app falls back to Tk's built-in clipboard. If tkinter is missing: `sudo apt install python3-tk`.

## Features

**Beginner (`--cli`):** choose length (min 8 enforced), choose character types (at least 2), generate and display, validate bad input, generate again without restarting.

**Advanced (GUI):**
- Slider and spinbox for length (8-64), checkboxes for uppercase, lowercase, numbers, symbols
- `secrets` module for cryptographically secure generation (not `random`)
- Strength bar and label (Weak / Medium / Strong)
- Guaranteed at least one character from each selected type
- Password is copied to the clipboard automatically on generation (`pyperclip`)
- Checkbox to exclude ambiguous characters (`0 O l 1 I |`)
- Last 5 passwords shown for the session (double-click one to copy it)

## Strength rating

Estimated entropy = `length x log2(size of character pool actually used)`.

| Entropy | Rating |
|---------|--------|
| < 50 bits | Weak |
| 50 - 74 bits | Medium |
| >= 75 bits | Strong |

For example, 16 characters using all four types is about 100 bits (Strong); 8 letters is about 46 bits (Weak).

## Security notes

- Why `secrets`: `random` is predictable if its state is known; `secrets` draws from the operating system's secure source.
- Positions of the guaranteed characters are hidden with a secure shuffle.
- Session history is held in memory only. It is **never written to a file** and disappears when the app closes.
- Clipboard contents can be read by other programs, so paste the password promptly and clear your clipboard history if you can.
