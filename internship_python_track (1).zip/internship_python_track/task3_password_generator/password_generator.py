#!/usr/bin/env python3
"""
Task 3 - Random Password Generator (Advanced tier; includes every Beginner feature)

Run:
    python password_generator.py         # GUI
    python password_generator.py --cli   # Beginner command-line version

Security notes
    * Uses the `secrets` module (cryptographically secure), never `random`.
    * Every selected character type is guaranteed to appear at least once.
    * The history of the last 5 passwords lives in memory only and is never written to disk.
"""
from __future__ import annotations

import argparse
import math
import secrets
import string
import sys
from collections import deque

try:
    import pyperclip
except ImportError:
    pyperclip = None

try:
    import tkinter as tk
    from tkinter import messagebox, ttk
except ImportError:
    tk = None

MIN_LENGTH, MAX_LENGTH = 8, 64
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.<>?"
AMBIGUOUS = "0Ol1I|"

CHAR_SETS = {
    "uppercase": string.ascii_uppercase,
    "lowercase": string.ascii_lowercase,
    "numbers": string.digits,
    "symbols": SYMBOLS,
}


# ----------------------------------------------------------------------------------------
# Core logic
# ----------------------------------------------------------------------------------------
def build_pools(selected: dict[str, bool], exclude_ambiguous: bool = False) -> list[str]:
    pools = []
    for name, chars in CHAR_SETS.items():
        if selected.get(name):
            if exclude_ambiguous:
                chars = "".join(c for c in chars if c not in AMBIGUOUS)
            pools.append(chars)
    return pools


def generate_password(length: int, selected: dict[str, bool], exclude_ambiguous: bool = False) -> str:
    """Generate a password of `length` containing >= 1 character from every selected type."""
    if not isinstance(length, int) or not MIN_LENGTH <= length <= MAX_LENGTH:
        raise ValueError(f"Length must be a whole number between {MIN_LENGTH} and {MAX_LENGTH}.")
    pools = build_pools(selected, exclude_ambiguous)
    if len(pools) < 2:
        raise ValueError("Select at least 2 character types.")
    chars = [secrets.choice(pool) for pool in pools]          # guarantee one of each type
    everything = "".join(pools)
    chars += [secrets.choice(everything) for _ in range(length - len(chars))]
    secrets.SystemRandom().shuffle(chars)                      # hide the guaranteed positions
    return "".join(chars)


def password_strength(password: str) -> tuple[str, float, float]:
    """Return (label, fraction 0-1, entropy_bits) from length and character diversity."""
    pool = 0
    if any(c in string.ascii_lowercase for c in password):
        pool += 26
    if any(c in string.ascii_uppercase for c in password):
        pool += 26
    if any(c in string.digits for c in password):
        pool += 10
    if any(not c.isalnum() for c in password):
        pool += len(SYMBOLS)
    bits = len(password) * math.log2(pool) if pool else 0.0
    label = "Weak" if bits < 50 else "Medium" if bits < 75 else "Strong"
    return label, min(bits / 100, 1.0), bits


# ----------------------------------------------------------------------------------------
# Beginner: command-line version
# ----------------------------------------------------------------------------------------
def _ask_length() -> int:
    while True:
        raw = input(f"Password length ({MIN_LENGTH}-{MAX_LENGTH}): ").strip()
        try:
            length = int(raw)
        except ValueError:
            print("  Error: please enter a whole number.")
            continue
        if MIN_LENGTH <= length <= MAX_LENGTH:
            return length
        print(f"  Error: length must be between {MIN_LENGTH} and {MAX_LENGTH}.")


def _ask_types() -> dict[str, bool]:
    while True:
        selected = {name: input(f"Include {name}? (y/n): ").strip().lower().startswith("y") for name in CHAR_SETS}
        if sum(selected.values()) >= 2:
            return selected
        print("  Error: choose at least 2 character types.")


def run_cli() -> None:
    print("=== Random Password Generator ===")
    while True:
        length = _ask_length()
        selected = _ask_types()
        password = generate_password(length, selected)
        label, _, bits = password_strength(password)
        print(f"\nYour password: {password}\nStrength: {label} ({bits:.0f} bits)\n")
        if input("Generate another? (y/n): ").strip().lower() != "y":
            break


# ----------------------------------------------------------------------------------------
# Advanced: GUI
# ----------------------------------------------------------------------------------------
class PasswordApp:
    STRENGTH_COLORS = {"Weak": "#dc2626", "Medium": "#f59e0b", "Strong": "#16a34a"}

    def __init__(self, root):
        self.root = root
        self.history: deque[str] = deque(maxlen=5)   # in memory only - never persisted
        root.title("Password Generator")
        root.resizable(False, False)

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        for label, color in self.STRENGTH_COLORS.items():
            style.configure(f"{label}.Horizontal.TProgressbar", background=color, troughcolor="#e5e7eb")

        self.length = tk.IntVar(value=16)
        self.options = {name: tk.BooleanVar(value=True) for name in CHAR_SETS}
        self.exclude = tk.BooleanVar(value=False)
        self.password = tk.StringVar()

        frm = ttk.Frame(root, padding=16)
        frm.pack()
        ttk.Label(frm, text="Password Generator", font=("Segoe UI", 16, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")

        ttk.Label(frm, text="Length:").grid(row=1, column=0, sticky="w", pady=(10, 0))
        tk.Scale(frm, from_=MIN_LENGTH, to=MAX_LENGTH, orient="horizontal", variable=self.length,
                 length=220, showvalue=False).grid(row=1, column=1, pady=(10, 0))
        ttk.Spinbox(frm, from_=MIN_LENGTH, to=MAX_LENGTH, textvariable=self.length, width=5).grid(row=1, column=2, pady=(10, 0))

        boxes = ttk.LabelFrame(frm, text="Include", padding=8)
        boxes.grid(row=2, column=0, columnspan=3, sticky="ew", pady=10)
        for i, name in enumerate(CHAR_SETS):
            ttk.Checkbutton(boxes, text=name.capitalize(), variable=self.options[name]).grid(row=i // 2, column=i % 2, sticky="w", padx=8, pady=2)
        ttk.Checkbutton(frm, text="Exclude ambiguous characters (0, O, l, 1, I, |)",
                        variable=self.exclude).grid(row=3, column=0, columnspan=3, sticky="w")

        ttk.Button(frm, text="Generate (auto-copies)", command=self.generate).grid(row=4, column=0, columnspan=2, sticky="ew", pady=10)
        ttk.Button(frm, text="Copy", command=self.copy_current).grid(row=4, column=2, sticky="ew", pady=10, padx=(6, 0))

        ttk.Entry(frm, textvariable=self.password, state="readonly", font=("Consolas", 13), width=40).grid(row=5, column=0, columnspan=3, sticky="ew")
        self.bar = ttk.Progressbar(frm, maximum=100, length=360, style="Weak.Horizontal.TProgressbar")
        self.bar.grid(row=6, column=0, columnspan=3, sticky="ew", pady=(10, 2))
        self.strength_label = ttk.Label(frm, text="Strength: -")
        self.strength_label.grid(row=7, column=0, columnspan=3, sticky="w")
        self.status = ttk.Label(frm, text="", foreground="#b91c1c", wraplength=360)
        self.status.grid(row=8, column=0, columnspan=3, sticky="w", pady=(4, 0))

        ttk.Label(frm, text="Last 5 passwords (this session only; double-click to copy)",
                  font=("Segoe UI", 9, "bold")).grid(row=9, column=0, columnspan=3, sticky="w", pady=(10, 2))
        self.listbox = tk.Listbox(frm, height=5, font=("Consolas", 10))
        self.listbox.grid(row=10, column=0, columnspan=3, sticky="ew")
        self.listbox.bind("<Double-Button-1>", self.copy_from_history)

    def _say(self, text: str, error: bool = False) -> None:
        self.status.config(text=text, foreground="#b91c1c" if error else "#166534")

    def generate(self) -> None:
        try:
            length = int(self.length.get())
        except (tk.TclError, ValueError):
            self._say(f"Length must be a whole number between {MIN_LENGTH} and {MAX_LENGTH}.", error=True)
            return
        selected = {name: var.get() for name, var in self.options.items()}
        try:
            pw = generate_password(length, selected, self.exclude.get())
        except ValueError as exc:
            self._say(str(exc), error=True)
            return
        self.password.set(pw)
        self.history.appendleft(pw)
        self.listbox.delete(0, "end")
        for item in self.history:
            self.listbox.insert("end", item)
        label, fraction, bits = password_strength(pw)
        self.bar.config(value=fraction * 100, style=f"{label}.Horizontal.TProgressbar")
        self.strength_label.config(text=f"Strength: {label} ({bits:.0f} bits)")
        self.copy_text(pw)

    def copy_text(self, text: str) -> None:
        try:
            if pyperclip is None:
                raise RuntimeError("pyperclip not installed")
            pyperclip.copy(text)
        except Exception:  # fall back to Tk's own clipboard
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.root.update()
        self._say("Copied to clipboard.")

    def copy_current(self) -> None:
        if self.password.get():
            self.copy_text(self.password.get())
        else:
            self._say("Generate a password first.", error=True)

    def copy_from_history(self, _event) -> None:
        selection = self.listbox.curselection()
        if selection:
            self.copy_text(self.listbox.get(selection[0]))


def run_gui() -> None:
    if tk is None:
        print("tkinter is not available on this system; falling back to the command-line version.")
        return run_cli()
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        print(f"Could not open a window ({exc}); falling back to the command-line version.")
        return run_cli()
    PasswordApp(root)
    root.mainloop()


def main() -> None:
    parser = argparse.ArgumentParser(description="Random password generator")
    parser.add_argument("--cli", action="store_true", help="run the command-line (Beginner) version")
    args = parser.parse_args()
    run_cli() if args.cli else run_gui()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        sys.exit(0)
